"""Injeksi bot.js ke halaman Moodle saat dijalankan di dalam SEB asli.

Kenapa proxy, bukan extension:
- Config SEB kamu (config (21).seb) melarang extension & preferences,
  tapi URLFilterEnable=false -> koneksi proxy + fetch ke API Gemini tetap lolos.
- BrowserExamKey tetap valid karena browser-nya SEB asli, bukan Chrome spoof.

Pakai:
  1. pip install mitmproxy
  2. mitmdump -s seb_bot/inject.py --listen-port 8080
  3. Install CA mitmproxy (http://mitm.it) sekali di Windows (Trusted Root).
  4. Set Windows Proxy -> 127.0.0.1:8080 SEBELUM buka SEB.
     (SEB dengan allowWlan=false tidak bisa ubah WiFi dari dalam,
      tapi proxy sistem Windows tetap dipakai.)
  5. Buka SEB -> login manual -> panel bot muncul otomatis.
  6. Setelah ujian: matikan proxy Windows lagi.

File bot.js dibaca dari folder yang sama dan disisipkan inline
sebelum </body> pada setiap halaman kuliah.itera.ac.id.
"""
from pathlib import Path

from mitmproxy import ctx, http

TARGET_HOST = "kuliah.itera.ac.id"
BOT_PATH = Path(__file__).with_name("bot.js")
KEY_PATH = Path(__file__).with_name("key.txt")
OAI_KEY_PATH = Path(__file__).with_name("oai_key.txt")


def load_bot() -> str:
    try:
        return BOT_PATH.read_text(encoding="utf-8")
    except OSError as exc:
        ctx.log.error(f"[seb-bot] gagal baca bot.js: {exc}")
        return ""


def load_key() -> str:
    """API key dibaca dari key.txt (satu baris). File ini jangan di-commit."""
    try:
        return KEY_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def load_oai_key() -> str:
    """API key Groq/OpenAI dari oai_key.txt (satu baris). Jangan di-commit."""
    try:
        return OAI_KEY_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def js_str(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("<", "\\x3c")


def response(flow: http.HTTPFlow) -> None:
    if TARGET_HOST not in (flow.request.pretty_host or ""):
        return
    ctype = flow.response.headers.get("content-type", "")
    if "text/html" not in ctype.lower():
        return
    if flow.response.status_code != 200:
        return

    bot = load_bot()
    if not bot:
        return
    try:
        html = flow.response.get_text()
    except ValueError:
        return
    if "seb-bot-panel" in html or "SEB Moodle PG Bot" in html:
        return  # sudah terinjeksi, jangan dobel
    marker = "</body>"
    key = load_key()
    # Suntik key sebelum bot.js agar tersedia sebagai window.__SEB_BOT_KEY.
    # SEB memakai profil fresh -> localStorage Chrome tidak terbawa, jadi ini wajib.
    key_tag = ""
    if key:
        key_tag += '<script>window.__SEB_BOT_KEY="' + js_str(key) + '";</script>\n'
    oai_key = load_oai_key()
    if oai_key:
        key_tag += '<script>window.__SEB_BOT_OAIKEY="' + js_str(oai_key) + '";</script>\n'
    tag = key_tag + "<script>/* seb-bot injected */\n" + bot + "\n</script>\n</body>"
    if marker in html.lower():
        # ganti kemunculan terakhir </body> (case-insensitive)
        idx = html.lower().rfind(marker)
        html = html[:idx] + tag + html[idx + len(marker):]
        flow.response.set_text(html)
        ctx.log.info(f"[seb-bot] injected -> {flow.request.path[:80]}")
